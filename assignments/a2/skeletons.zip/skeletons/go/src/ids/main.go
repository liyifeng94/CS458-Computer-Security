package main

import "github.com/google/gopacket"
import "github.com/google/gopacket/pcap"
import "fmt"

func main() {
	fmt.Println("Hello, world!")
}