#include <iostream>
#include <pcap.h>

using namespace std;

int main(int argc, char *argv[])
{
    if(argc != 1)
    {
        cerr<<"ERROR: Invalid args."<<endl;
        exit(1);
    }
    return 0;
}